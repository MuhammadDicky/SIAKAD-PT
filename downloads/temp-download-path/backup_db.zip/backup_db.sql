#
# TABLE STRUCTURE FOR: tbl_activity_log
#

DROP TABLE IF EXISTS `tbl_activity_log`;

CREATE TABLE `tbl_activity_log` (
  `id_activity` int(255) NOT NULL AUTO_INCREMENT,
  `id_data` int(255) NOT NULL,
  `data_change` varchar(10) NOT NULL,
  `action_change` int(1) NOT NULL,
  `change_date` date NOT NULL,
  PRIMARY KEY (`id_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_alumni
#

DROP TABLE IF EXISTS `tbl_alumni`;

CREATE TABLE `tbl_alumni` (
  `id_alni` int(255) NOT NULL AUTO_INCREMENT,
  `id_mhs_alni` int(255) NOT NULL,
  `tgl_yudisium` date NOT NULL,
  `tgl_lulus` date NOT NULL,
  PRIMARY KEY (`id_alni`),
  UNIQUE KEY `id_mhs_alni` (`id_mhs_alni`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('1', '11', '2017-06-21', '2017-12-26');
INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('16', '135', '2017-12-18', '2017-12-28');
INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('17', '187', '2017-12-14', '2017-12-05');
INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('18', '188', '2017-12-14', '2017-12-05');
INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('19', '236', '2017-12-31', '2018-01-31');
INSERT INTO `tbl_alumni` (`id_alni`, `id_mhs_alni`, `tgl_yudisium`, `tgl_lulus`) VALUES ('20', '237', '2017-12-31', '2018-01-31');


#
# TABLE STRUCTURE FOR: tbl_fakultas
#

DROP TABLE IF EXISTS `tbl_fakultas`;

CREATE TABLE `tbl_fakultas` (
  `id_fk` int(255) NOT NULL AUTO_INCREMENT,
  `nama_fakultas` varchar(30) NOT NULL,
  `dekan` varchar(50) NOT NULL,
  `tgl_berdiri` date NOT NULL,
  `akreditasi_fk` varchar(1) NOT NULL,
  PRIMARY KEY (`id_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_fakultas` (`id_fk`, `nama_fakultas`, `dekan`, `tgl_berdiri`, `akreditasi_fk`) VALUES ('1', 'Teknik Komputer', 'Dra. Rusmala Dewi M.T.', '2005-07-06', 'B');


#
# TABLE STRUCTURE FOR: tbl_identitas_pt
#

DROP TABLE IF EXISTS `tbl_identitas_pt`;

CREATE TABLE `tbl_identitas_pt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `kpt` varchar(10) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `status` varchar(12) NOT NULL,
  `btk_pendi` varchar(15) NOT NULL,
  `status_milik` varchar(30) NOT NULL,
  `tgl_berdiri` date NOT NULL,
  `sk_pend_sekolah` varchar(30) NOT NULL,
  `tgl_sk_pend` date NOT NULL,
  `sk_izin_op` varchar(30) NOT NULL,
  `tgl_sk_izin_op` date NOT NULL,
  `kebutu_khusus` varchar(30) NOT NULL,
  `bank` varchar(20) NOT NULL,
  `cabang_kcp_unit` varchar(10) NOT NULL,
  `rekening_nama` varchar(30) NOT NULL,
  `luas_tanah_m` varchar(10) NOT NULL,
  `luas_tanah_bm` varchar(10) NOT NULL,
  `sertifikat_iso` varchar(30) NOT NULL,
  `sumber_listrik` varchar(30) NOT NULL,
  `daya_listrik` varchar(10) NOT NULL,
  `akses_internet` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `rt` varchar(3) NOT NULL,
  `rw` varchar(3) NOT NULL,
  `dusun` varchar(20) NOT NULL,
  `desa_kelurahan` varchar(30) NOT NULL,
  `kecamatan` varchar(30) NOT NULL,
  `kabupaten` varchar(30) NOT NULL,
  `provinsi` varchar(30) NOT NULL,
  `kode_pos` varchar(7) NOT NULL,
  `telepon` varchar(10) NOT NULL,
  `fax` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `website` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_identitas_pt` (`id`, `nama`, `kpt`, `kategori`, `status`, `btk_pendi`, `status_milik`, `tgl_berdiri`, `sk_pend_sekolah`, `tgl_sk_pend`, `sk_izin_op`, `tgl_sk_izin_op`, `kebutu_khusus`, `bank`, `cabang_kcp_unit`, `rekening_nama`, `luas_tanah_m`, `luas_tanah_bm`, `sertifikat_iso`, `sumber_listrik`, `daya_listrik`, `akses_internet`, `alamat`, `rt`, `rw`, `dusun`, `desa_kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kode_pos`, `telepon`, `fax`, `email`, `website`) VALUES ('1', 'UNIVERSITAS COKROAMINOTO PALOPO', '091039', 'Swasta', 'Aktif', 'Universitas', 'Pemerintah Pusat', '2005-07-06', '95DO2005', '2005-07-06', '', '0000-00-00', '', '', '', '', '', '', 'Belum Bersertifikat', 'PLN', '', 'Serat Optik', 'Jln. Latammacelling No. 09-B', '01', '02', '', 'Tompotikka', 'Wara', '', '', '', '047122111', '0471325055', 'rektor@uncp.ac.id', 'www.uncp.ac.id');


#
# TABLE STRUCTURE FOR: tbl_jadwal_kuliah
#

DROP TABLE IF EXISTS `tbl_jadwal_kuliah`;

CREATE TABLE `tbl_jadwal_kuliah` (
  `id_jdl` int(255) NOT NULL AUTO_INCREMENT,
  `id_mk_jdl` int(255) NOT NULL,
  `id_ptk_jdl` int(255) NOT NULL,
  `id_thn_ak_jdl` int(255) NOT NULL,
  `hari_jdl` varchar(7) NOT NULL,
  `jam_mulai_jdl` varchar(5) NOT NULL,
  `jam_akhir_jdl` varchar(5) NOT NULL,
  `semester` int(2) NOT NULL,
  `kelas` varchar(8) NOT NULL,
  `ruang` varchar(12) NOT NULL,
  PRIMARY KEY (`id_jdl`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('4', '1', '60', '1', 'Kamis', '07:30', '09:10', '3', 'A', 'A1.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('5', '3', '1', '1', 'Selasa', '07:30', '09:10', '3', 'A', 'A2.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('6', '2', '1', '1', 'Rabu', '07:30', '09:10', '5', 'A', 'A2.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('13', '9', '1', '1', 'Kamis', '14:08', '14:08', '5', 'GAB.3', 'A8.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('14', '5', '1', '1', 'Rabu', '14:08', '14:08', '5', 'GAB.3', 'A8.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('15', '9', '1', '1', 'Kamis', '14:08', '14:08', '6', 'GAB.5', 'A8.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('16', '9', '1', '1', 'Minggu', '14:08', '16:30', '3', 'GAB.4', 'A8.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('18', '9', '1', '1', 'Selasa', '14:08', '14:08', '1', 'GAB.6', 'A8.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('19', '3', '1', '1', 'Jumat', '12:08', '14:08', '1', 'A', 'A8.LT3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('26', '2', '1', '1', 'Kamis', '14:08', '14:08', '1', 'A', 'B2.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('33', '1', '1', '1', 'Rabu', '08:40', '09:10', '1', 'A', 'A1.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('34', '9', '42', '1', 'Rabu', '14:30', '15:40', '1', 'GAB.1', 'A4.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('45', '1', '1', '1', 'Senin', '07:30', '09:10', '7', 'G', 'A1.LT2');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('55', '5', '42', '2', 'Rabu', '12:08', '14:08', '3', 'D', 'LAB.3');
INSERT INTO `tbl_jadwal_kuliah` (`id_jdl`, `id_mk_jdl`, `id_ptk_jdl`, `id_thn_ak_jdl`, `hari_jdl`, `jam_mulai_jdl`, `jam_akhir_jdl`, `semester`, `kelas`, `ruang`) VALUES ('56', '5', '1', '2', 'Sabtu', '09:08', '12:30', '4', 'G', 'A3.LT2');


#
# TABLE STRUCTURE FOR: tbl_kelas_nilai_mhs
#

DROP TABLE IF EXISTS `tbl_kelas_nilai_mhs`;

CREATE TABLE `tbl_kelas_nilai_mhs` (
  `id_kelas` int(255) NOT NULL AUTO_INCREMENT,
  `id_jdl_kls` int(255) NOT NULL,
  `id_mhs_kls` int(255) NOT NULL,
  `nilai_akhir` varchar(4) NOT NULL,
  `status_mhs_kls` int(1) NOT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('8', '5', '30', '91', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('9', '5', '11', '91', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('10', '33', '11', '90', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('13', '14', '30', '87', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('15', '26', '30', '87', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('24', '19', '11', '93', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('31', '15', '11', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('33', '33', '30', '85', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('34', '13', '11', '89', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('35', '34', '11', '89', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('36', '26', '11', '91', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('37', '6', '11', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('40', '55', '11', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('41', '14', '11', '88', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('42', '18', '11', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('43', '34', '30', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('46', '15', '30', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('48', '13', '30', '', '1');
INSERT INTO `tbl_kelas_nilai_mhs` (`id_kelas`, `id_jdl_kls`, `id_mhs_kls`, `nilai_akhir`, `status_mhs_kls`) VALUES ('50', '4', '30', '', '1');


#
# TABLE STRUCTURE FOR: tbl_konsentrasi_pd
#

DROP TABLE IF EXISTS `tbl_konsentrasi_pd`;

CREATE TABLE `tbl_konsentrasi_pd` (
  `id_konst` int(255) NOT NULL AUTO_INCREMENT,
  `id_pd_konst` int(255) NOT NULL,
  `nm_konsentrasi` varchar(50) NOT NULL,
  PRIMARY KEY (`id_konst`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_konsentrasi_pd` (`id_konst`, `id_pd_konst`, `nm_konsentrasi`) VALUES ('1', '1', 'Rekayasa Perangkat Lunak');
INSERT INTO `tbl_konsentrasi_pd` (`id_konst`, `id_pd_konst`, `nm_konsentrasi`) VALUES ('4', '1', 'Jaringan');
INSERT INTO `tbl_konsentrasi_pd` (`id_konst`, `id_pd_konst`, `nm_konsentrasi`) VALUES ('5', '1', 'Desain WEB');
INSERT INTO `tbl_konsentrasi_pd` (`id_konst`, `id_pd_konst`, `nm_konsentrasi`) VALUES ('6', '1', 'Sistem Informasi Geografi');
INSERT INTO `tbl_konsentrasi_pd` (`id_konst`, `id_pd_konst`, `nm_konsentrasi`) VALUES ('7', '1', 'Multimedia');


#
# TABLE STRUCTURE FOR: tbl_mahasiswa
#

DROP TABLE IF EXISTS `tbl_mahasiswa`;

CREATE TABLE `tbl_mahasiswa` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_pd_mhs` int(255) NOT NULL,
  `nisn` varchar(12) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `thn_angkatan` int(255) NOT NULL,
  `jk` varchar(1) NOT NULL,
  `tmp_lhr` varchar(50) NOT NULL,
  `tgl_lhr` date NOT NULL,
  `nik` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `rt` varchar(2) NOT NULL,
  `rw` varchar(2) NOT NULL,
  `dusun` varchar(20) NOT NULL,
  `kelurahan` varchar(30) NOT NULL,
  `kecamatan` varchar(30) NOT NULL,
  `kode_pos` varchar(6) NOT NULL,
  `jns_tinggal` varchar(30) NOT NULL,
  `alt_trans` varchar(36) NOT NULL,
  `tlp` varchar(11) NOT NULL,
  `hp` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status_verifikasi_mhs` tinyint(4) NOT NULL,
  `photo_mhs` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `search_mahasiswa_idx` (`id`,`nama`,`nisn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('11', '1', '1304411261', 'MUH. DICKY HIDAYAT LATIF', '9', 'L', 'Palopo', '1995-08-14', '7317061408950002', 'Islam', 'Jln. Anggrek Block C No. 5 Kota Palopo', '01', '02', '', 'Tompotikka', 'Wara', '91921', 'Wali', 'Sepeda motor', '', '082336826067', 'muh.dickyhidayat@gmail.com', '1', 'V6senvgmm2wEKNEjmSfU6512bd43d9caa6e02c990b0a82652dcaxDoEE8mBQAA4tn44Ty3u-mhs.jpg');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('30', '1', '1604411262', 'FEBRI DWI SATRIO BUNTOLOBO', '11', 'P', 'TALLUNGLIPU', '1995-03-01', '', 'Kristen', 'TALLUNGLIPU', '', '', '', 'TAGANI', 'Kec. Tallunglipu', '', 'Lainnya', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('40', '1', '1404411263', 'TEST', '10', 'L', 'Test', '2017-11-22', '122', 'Islam', 'Test', '01', '02', 'Test', 'Test', 'Test', '91920', 'Bersama orang tua', 'Sepeda motor', '', '', '', '0', 'NqjGIRIWvB8VFevajvwbd645920e395fedad7bbbed0eca3fe2e0KcrsVpvGG8r83crHote6-mhs.png');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('135', '36', '1704311095', 'MAHASISWA 095', '12', 'L', 'Test', '2017-11-15', '', 'Islam', 'Alamat Test', '', '', '', '', '', '', '', '', '', '', '', '0', 'trNA7iZZrWQpnzJRyM5M7f1de29e6da19d22b51c68001e7e0e541K35z84WVTSBeZ832ALX-mhs.png');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('136', '1', '1704411096', 'MAHASISWA 096', '12', 'P', 'Test', '2017-11-15', '', 'Islam', 'Alamat Test', '', '', '', '', '', '', '', '', '', '', '', '0', '06QptxQ2C4THOsemJOYH42a0e188f5033bc65bf8d78622277c4eK4GyHpOaUD3Lp0mxc8he-mhs.jpg');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('187', '36', '1704311100', 'MHS - 100', '12', 'L', 'Test', '2018-01-25', '', 'Islam', 'Test', '', '', '', '', '', '', '', '', '', '', '', '0', 'k2Nxb15JHuKbegla3mRS31fefc0e570cb3860f2a6d4b38c6490dIDyvkPSDGMT4BW8fKszl-mhs.jpg');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('188', '36', '1704311101', 'MHS - 101', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('189', '36', '1704311102', 'MHS - 102', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('190', '36', '1704311103', 'MHS - 103', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('191', '36', '1704311104', 'MHS - 104', '12', 'L', 'Test', '2009-06-24', '', 'Islam', 'Test', '', '', '', '', '', '', '', '', '', '', '', '0', '2alFlgzgQDzD7NboMtAw0aa1883c6411f7873cb83dacb17b0afcKzXYZN40DHZfoPQbU1Rt-mhs.png');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('192', '36', '1704311105', 'MHS - 105', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('193', '36', '1704311106', 'MHS - 106', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('194', '36', '1704311107', 'MHS - 107', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('195', '36', '1704311108', 'MHS - 108', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('196', '36', '1704311109', 'MHS - 109', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('197', '36', '1704311110', 'MHS - 110', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('198', '36', '1704311111', 'MHS - 111', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('199', '36', '1704311112', 'MHS - 112', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('200', '36', '1704311113', 'MHS - 113', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('201', '36', '1704311114', 'MHS - 114', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('202', '36', '1704311115', 'MHS - 115', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('203', '36', '1704311116', 'MHS - 116', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('204', '36', '1704311117', 'MHS - 117', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('205', '36', '1704311118', 'MHS - 118', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('206', '36', '1704311119', 'MHS - 119', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('207', '36', '1704311120', 'MHS - 120', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('208', '36', '1704311121', 'MHS - 121', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('209', '36', '1704311122', 'MHS - 122', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('210', '36', '1704311123', 'MHS - 123', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('211', '36', '1704311124', 'MHS - 124', '12', 'L', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('212', '36', '1704311125', 'MHS - 125', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('213', '36', '1704311126', 'MHS - 126', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('214', '36', '1704311127', 'MHS - 127', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('215', '36', '1704311128', 'MHS - 128', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('216', '36', '1704311129', 'MHS - 129', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('217', '36', '1704311130', 'MHS - 130', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('218', '36', '1704311131', 'MHS - 131', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('219', '36', '1704311132', 'MHS - 132', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('220', '36', '1704311133', 'MHS - 133', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('221', '36', '1704311134', 'MHS - 134', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('222', '36', '1704311135', 'MHS - 135', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('223', '36', '1704311136', 'MHS - 136', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('224', '36', '1704311137', 'MHS - 137', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('225', '36', '1704311138', 'MHS - 138', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('226', '36', '1704311139', 'MHS - 139', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('227', '36', '1704311140', 'MHS - 140', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('228', '36', '1704311141', 'MHS - 141', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('229', '36', '1704311142', 'MHS - 142', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('230', '36', '1704311143', 'MHS - 143', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('231', '36', '1704311144', 'MHS - 144', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('232', '36', '1704311145', 'MHS - 145', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('233', '36', '1704311146', 'MHS - 146', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('234', '36', '1704311147', 'MHS - 147', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('235', '36', '1704311148', 'MHS - 148', '12', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('236', '1', '1704411001', 'MHS - TI 1', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 1', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('237', '1', '1704411002', 'MHS - TI 2', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 2', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('238', '1', '1704411003', 'MHS - TI 3', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 3', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('239', '1', '1704411004', 'MHS - TI 4', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 4', '', '', '', '', '', '', '', '', '', '', '', '0', 'DLI6Vsk3mvuZpULP320k555d6702c950ecb729a966504af0a635FTwJmLoLUaKXifb8JYEo-mhs.jpg');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('240', '1', '1704411005', 'MHS - TI 5', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 5', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('241', '1', '1704411006', 'MHS - TI 6', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 6', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('242', '1', '1704411007', 'MHS - TI 7', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 7', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('243', '1', '1704411008', 'MHS - TI 8', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 8', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('244', '1', '1704411009', 'MHS - TI 9', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 9', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('245', '1', '1704411010', 'MHS - TI 10', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 10', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('246', '1', '1704411011', 'MHS - TI 11', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 11', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('247', '1', '1704411012', 'MHS - TI 12', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 12', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('248', '1', '1704411013', 'MHS - TI 13', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 13', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('249', '1', '1704411014', 'MHS - TI 14', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 14', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('250', '1', '1704411015', 'MHS - TI 15', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 15', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('251', '1', '1704411016', 'MHS - TI 16', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 16', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('252', '1', '1704411017', 'MHS - TI 17', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 17', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('253', '1', '1704411018', 'MHS - TI 18', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 18', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('254', '1', '1704411019', 'MHS - TI 19', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 19', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('255', '1', '1704411020', 'MHS - TI 20', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 20', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('256', '1', '1704411021', 'MHS - TI 21', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 21', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('257', '1', '1704411022', 'MHS - TI 22', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 22', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('258', '1', '1704411023', 'MHS - TI 23', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 23', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('259', '1', '1704411024', 'MHS - TI 24', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 24', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('260', '1', '1704411025', 'MHS - TI 25', '12', 'L', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 25', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('261', '1', '1704411026', 'MHS - TI 26', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 26', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('262', '1', '1704411027', 'MHS - TI 27', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 27', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('263', '1', '1704411028', 'MHS - TI 28', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 28', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('264', '1', '1704411029', 'MHS - TI 29', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 29', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('265', '1', '1704411030', 'MHS - TI 30', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 30', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('266', '1', '1704411031', 'MHS - TI 31', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 31', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('267', '1', '1704411032', 'MHS - TI 32', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 32', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('268', '1', '1704411033', 'MHS - TI 33', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 33', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('269', '1', '1704411034', 'MHS - TI 34', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 34', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('270', '1', '1704411035', 'MHS - TI 35', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 35', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('271', '1', '1704411036', 'MHS - TI 36', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 36', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('272', '1', '1704411037', 'MHS - TI 37', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 37', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('273', '1', '1704411038', 'MHS - TI 38', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 38', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('274', '1', '1704411039', 'MHS - TI 39', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 39', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('275', '1', '1704411040', 'MHS - TI 40', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 40', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('276', '1', '1704411041', 'MHS - TI 41', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 41', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('277', '1', '1704411042', 'MHS - TI 42', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 42', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('278', '1', '1704411043', 'MHS - TI 43', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 43', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('279', '1', '1704411044', 'MHS - TI 44', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 44', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('280', '1', '1704411045', 'MHS - TI 45', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 45', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('281', '1', '1704411046', 'MHS - TI 46', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 46', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('282', '1', '1704411047', 'MHS - TI 47', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 47', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('283', '1', '1704411048', 'MHS - TI 48', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 48', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('284', '1', '1704411049', 'MHS - TI 49', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 49', '', '', '', '', '', '', '', '', '', '', '', '0', '');
INSERT INTO `tbl_mahasiswa` (`id`, `id_pd_mhs`, `nisn`, `nama`, `thn_angkatan`, `jk`, `tmp_lhr`, `tgl_lhr`, `nik`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kecamatan`, `kode_pos`, `jns_tinggal`, `alt_trans`, `tlp`, `hp`, `email`, `status_verifikasi_mhs`, `photo_mhs`) VALUES ('285', '1', '1704411050', 'MHS - TI 50', '12', 'P', 'Palopo', '1997-08-14', '', 'Islam', 'TEST 50', '', '', '', '', '', '', '', '', '', '', '', '0', '');


#
# TABLE STRUCTURE FOR: tbl_main_menu_list
#

DROP TABLE IF EXISTS `tbl_main_menu_list`;

CREATE TABLE `tbl_main_menu_list` (
  `id_menu` int(255) NOT NULL AUTO_INCREMENT,
  `nm_menu` varchar(50) NOT NULL,
  `level_access_menu` varchar(10) NOT NULL,
  `status_access_menu` varchar(1) NOT NULL,
  `sort_menu` varchar(2) NOT NULL,
  `link_menu` varchar(100) NOT NULL,
  `icon_menu` varchar(20) NOT NULL,
  `color_menu` varchar(10) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('1', 'Dashboard', 'admin', '1', '1', '', 'fa fa-dashboard', '#00c0ef');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('2', 'Data Master', 'admin', '1', '2', 'data_master', 'fa fa-archive', '#dd4b39');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('4', 'Data Pengguna', 'admin', '1', '3', 'data_pengguna', 'fa fa-users', '#00a65a');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('5', 'Data Akademik', 'admin', '1', '4', 'data_akademik', 'fa fa-list-alt', '#f39c12');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('6', 'Data Content', 'admin', '0', '5', 'data_content', 'fa fa-file-text', '#39cccc');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('7', 'Pusat Unggahan', 'admin', '0', '6', 'pusat_unggahan', 'fa fa-cloud-upload', '#3c8dbc');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('8', 'Dashboard', 'user', '1', '1', '', 'fa fa-dashboard', '#00c0ef');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('9', 'Identitas Perguruan Tinggi', 'user', '1', '2', 'profil_pt', 'fa fa-university', '#dd4b39');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('10', 'Pusat Unduhan', 'user', '0', '5', 'pusat_unduhan', 'fa fa-cloud-download', '#3c8dbc');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('11', 'Beranda Mahasiswa', 'mhs', '1', '3', 'beranda_mhs', 'fa fa-list-alt', '#f39c12');
INSERT INTO `tbl_main_menu_list` (`id_menu`, `nm_menu`, `level_access_menu`, `status_access_menu`, `sort_menu`, `link_menu`, `icon_menu`, `color_menu`) VALUES ('12', 'Beranda Tenaga Pendidik', 'ptk', '1', '4', 'beranda_ptk', 'fa fa-list-alt', '#f39c12');


#
# TABLE STRUCTURE FOR: tbl_mata_kuliah
#

DROP TABLE IF EXISTS `tbl_mata_kuliah`;

CREATE TABLE `tbl_mata_kuliah` (
  `id_mk` int(255) NOT NULL AUTO_INCREMENT,
  `id_pd_mk` int(255) NOT NULL,
  `kode_mk` varchar(7) NOT NULL,
  `nama_mk` varchar(70) NOT NULL,
  `jml_sks` int(1) NOT NULL,
  `jenis_jdl` int(255) NOT NULL,
  PRIMARY KEY (`id_mk`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('1', '1', 'DU001', 'Pendidikan Agama', '3', '0');
INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('2', '1', 'DU003', 'Pendidikan Pancasila', '2', '0');
INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('3', '1', 'DU004', 'Bahasa Indonesia', '3', '0');
INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('5', '1', 'KM001', 'Logika Informatika', '2', '1');
INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('9', '1', 'KM004', 'Algoritma Dan Pemrograman Terstruktur', '3', '5');
INSERT INTO `tbl_mata_kuliah` (`id_mk`, `id_pd_mk`, `kode_mk`, `nama_mk`, `jml_sks`, `jenis_jdl`) VALUES ('42', '36', 'MK001', 'Pengetahuan Komputer', '2', '0');


#
# TABLE STRUCTURE FOR: tbl_mhs_do
#

DROP TABLE IF EXISTS `tbl_mhs_do`;

CREATE TABLE `tbl_mhs_do` (
  `id_DO` int(255) NOT NULL AUTO_INCREMENT,
  `id_mhs_DO` int(255) NOT NULL,
  `tgl_drop_out` date NOT NULL,
  `drop_out_reason` varchar(100) NOT NULL,
  PRIMARY KEY (`id_DO`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('54', '40', '2017-12-14', '');
INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('55', '136', '2017-12-14', '');
INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('56', '191', '2017-12-20', '');
INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('57', '194', '2017-12-20', '');
INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('58', '195', '2017-12-20', '');
INSERT INTO `tbl_mhs_do` (`id_DO`, `id_mhs_DO`, `tgl_drop_out`, `drop_out_reason`) VALUES ('59', '241', '2018-01-02', '');


#
# TABLE STRUCTURE FOR: tbl_nilai_mhs
#

DROP TABLE IF EXISTS `tbl_nilai_mhs`;

CREATE TABLE `tbl_nilai_mhs` (
  `id_nilai` int(255) NOT NULL AUTO_INCREMENT,
  `id_kls_nilai` int(255) NOT NULL,
  `nilai_akhir` varchar(4) NOT NULL,
  PRIMARY KEY (`id_nilai`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_ortu_wali
#

DROP TABLE IF EXISTS `tbl_ortu_wali`;

CREATE TABLE `tbl_ortu_wali` (
  `id_ortu` int(255) NOT NULL AUTO_INCREMENT,
  `id_mhs_ortu` int(255) NOT NULL,
  `nm_ayah` varchar(50) NOT NULL,
  `thn_lhr_ayah` int(11) NOT NULL,
  `pendi_ayah` varchar(30) NOT NULL,
  `pekerjaan_ayah` varchar(30) NOT NULL,
  `penghasilan_ayah` varchar(50) NOT NULL,
  `nik_ayah` varchar(20) NOT NULL,
  `nm_ibu` varchar(50) NOT NULL,
  `thn_lhr_ibu` int(11) NOT NULL,
  `pendi_ibu` varchar(30) NOT NULL,
  `pekerjaan_ibu` varchar(30) NOT NULL,
  `penghasilan_ibu` varchar(50) NOT NULL,
  `nik_ibu` varchar(20) NOT NULL,
  `nm_wali` varchar(50) NOT NULL,
  `thn_lhr_wali` int(11) NOT NULL,
  `pendi_wali` varchar(30) NOT NULL,
  `pekerjaan_wali` varchar(30) NOT NULL,
  `penghasilan_wali` varchar(50) NOT NULL,
  `nik_wali` varchar(20) NOT NULL,
  PRIMARY KEY (`id_ortu`)
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('6', '11', 'ABDUL LATIF', '1952', 'SMP / sederajat', 'Wiraswata', 'Kurang dari Rp. 500.000', '', 'INDARBIATI', '0', 'SMP / sederajat', '', '', '', 'KASWATI MUCHTAR', '0', 'S1', 'Karyawan swasta', 'Rp. 1.000.000 - Rp. 2.000.000', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('77', '30', 'TEST', '1952', 'SMP / sederajat', 'Wiraswata', 'Kurang dari Rp. 500.000', '', 'TEST M', '0', 'SMP / sederajat', '', '', '', 'TEST W', '0', 'S1', 'Karyawan swasta', 'Rp. 1.000.000 - Rp. 2.000.000', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('87', '40', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('182', '135', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('183', '136', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('234', '187', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('235', '188', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('236', '189', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('237', '190', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('238', '191', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('239', '192', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('240', '193', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('241', '194', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('242', '195', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('243', '196', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('244', '197', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('245', '198', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('246', '199', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('247', '200', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('248', '201', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('249', '202', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('250', '203', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('251', '204', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('252', '205', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('253', '206', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('254', '207', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('255', '208', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('256', '209', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('257', '210', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('258', '211', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('259', '212', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('260', '213', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('261', '214', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('262', '215', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('263', '216', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('264', '217', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('265', '218', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('266', '219', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('267', '220', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('268', '221', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('269', '222', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('270', '223', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('271', '224', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('272', '225', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('273', '226', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('274', '227', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('275', '228', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('276', '229', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('277', '230', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('278', '231', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('279', '232', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('280', '233', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('281', '234', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('282', '235', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('283', '236', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('284', '237', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('285', '238', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('286', '239', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('287', '240', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('288', '241', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('289', '242', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('290', '243', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('291', '244', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('292', '245', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('293', '246', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('294', '247', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('295', '248', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('296', '249', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('297', '250', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('298', '251', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('299', '252', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('300', '253', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('301', '254', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('302', '255', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('303', '256', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('304', '257', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('305', '258', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('306', '259', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('307', '260', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('308', '261', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('309', '262', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('310', '263', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('311', '264', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('312', '265', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('313', '266', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('314', '267', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('315', '268', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('316', '269', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('317', '270', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('318', '271', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('319', '272', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('320', '273', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('321', '274', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('322', '275', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('323', '276', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('324', '277', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('325', '278', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('326', '279', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('327', '280', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('328', '281', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('329', '282', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('330', '283', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('331', '284', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');
INSERT INTO `tbl_ortu_wali` (`id_ortu`, `id_mhs_ortu`, `nm_ayah`, `thn_lhr_ayah`, `pendi_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nik_ayah`, `nm_ibu`, `thn_lhr_ibu`, `pendi_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nik_ibu`, `nm_wali`, `thn_lhr_wali`, `pendi_wali`, `pekerjaan_wali`, `penghasilan_wali`, `nik_wali`) VALUES ('332', '285', '', '0', '', '', '', '', '', '0', '', '', '', '', '', '0', '', '', '', '');


#
# TABLE STRUCTURE FOR: tbl_penelitian_ptk
#

DROP TABLE IF EXISTS `tbl_penelitian_ptk`;

CREATE TABLE `tbl_penelitian_ptk` (
  `id_penelitian_ptk` int(255) NOT NULL AUTO_INCREMENT,
  `id_ptk_rsch` int(255) NOT NULL,
  `judul_penelitian` varchar(200) NOT NULL,
  `bidang_ilmu` varchar(50) NOT NULL,
  `lembaga` varchar(100) NOT NULL,
  PRIMARY KEY (`id_penelitian_ptk`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_penelitian_ptk` (`id_penelitian_ptk`, `id_ptk_rsch`, `judul_penelitian`, `bidang_ilmu`, `lembaga`) VALUES ('5', '1', 'Sistem Informasi Akademik SMK 1 Palopo', 'Teknik Komputer', 'SMK 1 Palopo');


#
# TABLE STRUCTURE FOR: tbl_prodi
#

DROP TABLE IF EXISTS `tbl_prodi`;

CREATE TABLE `tbl_prodi` (
  `id_prodi` int(255) NOT NULL AUTO_INCREMENT,
  `id_fk_pd` int(255) NOT NULL,
  `kode_prodi` varchar(6) NOT NULL,
  `nama_prodi` varchar(70) NOT NULL,
  `nama_kprodi` varchar(50) NOT NULL,
  `jenjang_prodi` varchar(5) NOT NULL,
  `akreditasi_prodi` varchar(1) NOT NULL,
  `status_prodi` int(1) NOT NULL,
  `tgl_berdiri_prodi` date NOT NULL,
  `sk_peny_prodi` varchar(20) NOT NULL,
  `tgl_sk_prodi` date NOT NULL,
  `alamat_prodi` varchar(100) NOT NULL,
  `kode_pos_prodi` varchar(7) NOT NULL,
  `telpon_prodi` varchar(12) NOT NULL,
  `fax_prodi` varchar(12) NOT NULL,
  `email_prodi` varchar(50) NOT NULL,
  `website_prodi` varchar(50) NOT NULL,
  PRIMARY KEY (`id_prodi`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_prodi` (`id_prodi`, `id_fk_pd`, `kode_prodi`, `nama_prodi`, `nama_kprodi`, `jenjang_prodi`, `akreditasi_prodi`, `status_prodi`, `tgl_berdiri_prodi`, `sk_peny_prodi`, `tgl_sk_prodi`, `alamat_prodi`, `kode_pos_prodi`, `telpon_prodi`, `fax_prodi`, `email_prodi`, `website_prodi`) VALUES ('1', '1', '55201', 'Teknik Informatika', 'Nirsal, S.kom., M.Pd', 'S1', 'B', '1', '2005-07-06', '1483/D/K-IX/2010', '2010-03-04', 'Palopo', '', '', '', '', '');
INSERT INTO `tbl_prodi` (`id_prodi`, `id_fk_pd`, `kode_prodi`, `nama_prodi`, `nama_kprodi`, `jenjang_prodi`, `akreditasi_prodi`, `status_prodi`, `tgl_berdiri_prodi`, `sk_peny_prodi`, `tgl_sk_prodi`, `alamat_prodi`, `kode_pos_prodi`, `telpon_prodi`, `fax_prodi`, `email_prodi`, `website_prodi`) VALUES ('36', '1', '50102', 'Sistem Informasi', 'Test', 'S1', 'B', '1', '2017-09-06', '', '2017-09-06', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: tbl_ptk
#

DROP TABLE IF EXISTS `tbl_ptk`;

CREATE TABLE `tbl_ptk` (
  `id_ptk` int(255) NOT NULL AUTO_INCREMENT,
  `jurusan_prodi` int(255) NOT NULL,
  `nama_ptk` varchar(50) NOT NULL,
  `nuptk` varchar(17) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `jk_ptk` varchar(1) NOT NULL,
  `tmp_lhr_ptk` varchar(50) NOT NULL,
  `tgl_lhr_ptk` date NOT NULL,
  `nik_ptk` varchar(20) NOT NULL,
  `agama_ptk` int(1) NOT NULL,
  `alamat_ptk` varchar(50) NOT NULL,
  `rt_ptk` varchar(2) NOT NULL,
  `rw_ptk` varchar(2) NOT NULL,
  `dusun_ptk` varchar(20) NOT NULL,
  `kelurahan_ptk` varchar(30) NOT NULL,
  `kecamatan_ptk` varchar(30) NOT NULL,
  `kode_pos_ptk` varchar(6) NOT NULL,
  `tlp_ptk` varchar(11) NOT NULL,
  `hp_ptk` varchar(12) NOT NULL,
  `email_ptk` varchar(50) NOT NULL,
  `status_ptk` int(1) NOT NULL,
  `status_aktif_ptk` int(1) NOT NULL,
  `jenjang` int(1) NOT NULL,
  `status_verifikasi_ptk` tinyint(4) NOT NULL,
  `photo_ptk` varchar(120) NOT NULL,
  PRIMARY KEY (`id_ptk`),
  KEY `ptk_idx` (`id_ptk`,`jurusan_prodi`,`nama_ptk`,`nuptk`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_ptk` (`id_ptk`, `jurusan_prodi`, `nama_ptk`, `nuptk`, `nip`, `jk_ptk`, `tmp_lhr_ptk`, `tgl_lhr_ptk`, `nik_ptk`, `agama_ptk`, `alamat_ptk`, `rt_ptk`, `rw_ptk`, `dusun_ptk`, `kelurahan_ptk`, `kecamatan_ptk`, `kode_pos_ptk`, `tlp_ptk`, `hp_ptk`, `email_ptk`, `status_ptk`, `status_aktif_ptk`, `jenjang`, `status_verifikasi_ptk`, `photo_ptk`) VALUES ('1', '1', 'Ahmad Abrar', '7539761663200032', '198302072010011025', 'L', 'Kendari', '1985-06-26', '12345', '1', 'Jln. Test', '02', '01', 'Test', 'Test', 'Test', '91922', '041243', '082003004005', 'abrar@gmail.com', '1', '4', '1', '1', 'jaMwIGOOCVhs9dhUKVOpc4ca4238a0b923820dcc509a6f75849bVSFztLDYCUmcdlunwU5A-ptk.jpg');
INSERT INTO `tbl_ptk` (`id_ptk`, `jurusan_prodi`, `nama_ptk`, `nuptk`, `nip`, `jk_ptk`, `tmp_lhr_ptk`, `tgl_lhr_ptk`, `nik_ptk`, `agama_ptk`, `alamat_ptk`, `rt_ptk`, `rw_ptk`, `dusun_ptk`, `kelurahan_ptk`, `kecamatan_ptk`, `kode_pos_ptk`, `tlp_ptk`, `hp_ptk`, `email_ptk`, `status_ptk`, `status_aktif_ptk`, `jenjang`, `status_verifikasi_ptk`, `photo_ptk`) VALUES ('25', '36', 'Asgar', '12345', '198410282015031006', 'L', 'BALANDAI', '1984-10-28', '', '1', '', '', '', '', '', '', '', '', '', '', '1', '3', '1', '0', 'le50PGjShVRLLhhvYhRo8e296a067a37563370ded05f5a3bf3ec5q047znHMSra57HXxHYG-ptk.jpg');
INSERT INTO `tbl_ptk` (`id_ptk`, `jurusan_prodi`, `nama_ptk`, `nuptk`, `nip`, `jk_ptk`, `tmp_lhr_ptk`, `tgl_lhr_ptk`, `nik_ptk`, `agama_ptk`, `alamat_ptk`, `rt_ptk`, `rw_ptk`, `dusun_ptk`, `kelurahan_ptk`, `kecamatan_ptk`, `kode_pos_ptk`, `tlp_ptk`, `hp_ptk`, `email_ptk`, `status_ptk`, `status_aktif_ptk`, `jenjang`, `status_verifikasi_ptk`, `photo_ptk`) VALUES ('42', '1', 'Innaha Ummi Maftuha Rahmawati', '1540749650300013', '197112081997022003', 'P', 'Ngawi', '1986-02-09', '', '0', '', '', '', '', '', '', '', '', '', '', '1', '1', '2', '2', 'kX9rijX9T2x4pMyJ0EgAa1d0c6e83f027327d8461063f4ac58a6HbgIYw5xoDQqPtqABwvg-ptk.png');
INSERT INTO `tbl_ptk` (`id_ptk`, `jurusan_prodi`, `nama_ptk`, `nuptk`, `nip`, `jk_ptk`, `tmp_lhr_ptk`, `tgl_lhr_ptk`, `nik_ptk`, `agama_ptk`, `alamat_ptk`, `rt_ptk`, `rw_ptk`, `dusun_ptk`, `kelurahan_ptk`, `kecamatan_ptk`, `kode_pos_ptk`, `tlp_ptk`, `hp_ptk`, `email_ptk`, `status_ptk`, `status_aktif_ptk`, `jenjang`, `status_verifikasi_ptk`, `photo_ptk`) VALUES ('60', '1', 'Rahayu', '991231231', '', 'P', 'PALOPO', '1967-04-23', '', '0', '', '', '', '', '', '', '', '', '', '', '1', '1', '1', '0', '');


#
# TABLE STRUCTURE FOR: tbl_ptk_studi
#

DROP TABLE IF EXISTS `tbl_ptk_studi`;

CREATE TABLE `tbl_ptk_studi` (
  `id_studi` int(255) NOT NULL AUTO_INCREMENT,
  `id_ptk_studi` int(255) NOT NULL,
  `nama_pt_studi` varchar(50) NOT NULL,
  `studi_ptk` varchar(70) NOT NULL,
  `jenjang_studi_ptk` varchar(5) NOT NULL,
  `gelar_ak_ptk` varchar(7) NOT NULL,
  `tgl_ijazah_ptk` date NOT NULL,
  PRIMARY KEY (`id_studi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_ptk_studi` (`id_studi`, `id_ptk_studi`, `nama_pt_studi`, `studi_ptk`, `jenjang_studi_ptk`, `gelar_ak_ptk`, `tgl_ijazah_ptk`) VALUES ('1', '1', 'Universitas Cokroaminoto Palopo', 'Teknik Informatika', 'S1', 'S.Kom', '2005-07-06');


#
# TABLE STRUCTURE FOR: tbl_sub_menu_list
#

DROP TABLE IF EXISTS `tbl_sub_menu_list`;

CREATE TABLE `tbl_sub_menu_list` (
  `id_sub_menu` int(255) NOT NULL AUTO_INCREMENT,
  `id_parent_menu` int(255) NOT NULL,
  `nm_sub_menu` varchar(50) NOT NULL,
  `status_access_sub_menu` varchar(1) NOT NULL,
  `sort_sub_menu` varchar(2) NOT NULL,
  `link_sub_menu` varchar(100) NOT NULL,
  `icon_sub_menu` varchar(20) NOT NULL,
  PRIMARY KEY (`id_sub_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('1', '5', 'Data Mahasiswa', '1', '1', 'data_mahasiswa', 'fa fa-users');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('2', '2', 'Data Identitas Perguruan Tinggi', '1', '1', 'data_identitas_pt', 'fa fa-university');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('3', '2', 'Data Fakultas & Program Studi', '1', '2', 'data_fakultas_pstudi', 'fa fa-circle-o');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('4', '5', 'Data Tenaga Pendidik', '1', '2', 'data_ptk', 'fa fa-circle-o');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('5', '11', 'Data Mahasiswa', '1', '1', 'data_mhs', 'fa fa-users');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('6', '11', 'Jadwal Kuliah', '1', '2', 'data_jadwal', 'fa fa-books');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('7', '2', 'Data Tahun Akademik', '1', '3', 'data_thn_akademik', 'fa fa-calendar');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('8', '2', 'Data Tahun Angkatan', '1', '4', 'data_angkatan', 'fa fa-c');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('9', '4', 'Mahasiswa', '1', '1', 'data_pengguna_mahasiswa', 'fa fa-u');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('10', '4', 'Tenaga Pendidik', '1', '2', 'data_pengguna_ptk', 'fa fa-users');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('11', '5', 'Data Mata Kuliah', '1', '3', 'data_mata_kuliah', 'fa fa-books');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('12', '5', 'Data Jadwal Kuliah & Kelas', '1', '4', 'data_jadwal_kuliah', 'fa fa-');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('13', '5', 'Data Nilai Mahasiswa', '1', '5', 'data_nilai_mhs', 'fa fa-list');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('14', '5', 'Data Alumni & Drop Out', '1', '6', 'data_alumni_do', 'fa fa-graduation');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('15', '4', 'Data Pengunjung', '2', '3', 'data_pengunjung', 'fa fa-users');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('17', '11', 'Nilai Mahasiswa', '1', '3', 'nilai_mhs', '');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('18', '12', 'Data Tenaga Pendidik', '1', '1', 'data_tenaga_pendidik', 'fa fa-user-secret');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('19', '12', 'Jadwal Mengajar', '1', '2', 'jadwal_mengajar', 'fa fa-list');
INSERT INTO `tbl_sub_menu_list` (`id_sub_menu`, `id_parent_menu`, `nm_sub_menu`, `status_access_sub_menu`, `sort_sub_menu`, `link_sub_menu`, `icon_sub_menu`) VALUES ('20', '12', 'Nilai Mahasiswa', '1', '3', 'nilai_mhs', 'fa fa-list');


#
# TABLE STRUCTURE FOR: tbl_thn_akademik
#

DROP TABLE IF EXISTS `tbl_thn_akademik`;

CREATE TABLE `tbl_thn_akademik` (
  `id_thn_ak` int(255) NOT NULL AUTO_INCREMENT,
  `thn_ajaran_jdl` varchar(6) NOT NULL,
  `tgl_mulai_thn_ajar` date NOT NULL,
  `tgl_akhir_thn_ajar` date NOT NULL,
  `status_jdl` int(1) NOT NULL,
  `status_inp_nilai` int(1) NOT NULL,
  `on_going_status` int(1) NOT NULL,
  PRIMARY KEY (`id_thn_ak`),
  UNIQUE KEY `thn_ajaran_jdl` (`thn_ajaran_jdl`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_thn_akademik` (`id_thn_ak`, `thn_ajaran_jdl`, `tgl_mulai_thn_ajar`, `tgl_akhir_thn_ajar`, `status_jdl`, `status_inp_nilai`, `on_going_status`) VALUES ('1', '2017/1', '2017-08-14', '2017-12-28', '1', '1', '0');
INSERT INTO `tbl_thn_akademik` (`id_thn_ak`, `thn_ajaran_jdl`, `tgl_mulai_thn_ajar`, `tgl_akhir_thn_ajar`, `status_jdl`, `status_inp_nilai`, `on_going_status`) VALUES ('2', '2016/2', '2017-01-26', '2017-07-27', '0', '0', '0');


#
# TABLE STRUCTURE FOR: tbl_thn_angkatan
#

DROP TABLE IF EXISTS `tbl_thn_angkatan`;

CREATE TABLE `tbl_thn_angkatan` (
  `id_thn_angkatan` int(255) NOT NULL AUTO_INCREMENT,
  `tahun_angkatan` int(5) NOT NULL,
  `tgl_masuk_angkatan` date NOT NULL,
  PRIMARY KEY (`id_thn_angkatan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_thn_angkatan` (`id_thn_angkatan`, `tahun_angkatan`, `tgl_masuk_angkatan`) VALUES ('9', '2013', '2013-08-24');
INSERT INTO `tbl_thn_angkatan` (`id_thn_angkatan`, `tahun_angkatan`, `tgl_masuk_angkatan`) VALUES ('10', '2014', '0000-00-00');
INSERT INTO `tbl_thn_angkatan` (`id_thn_angkatan`, `tahun_angkatan`, `tgl_masuk_angkatan`) VALUES ('11', '2016', '2016-08-26');
INSERT INTO `tbl_thn_angkatan` (`id_thn_angkatan`, `tahun_angkatan`, `tgl_masuk_angkatan`) VALUES ('12', '2017', '2016-07-14');


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(255) NOT NULL AUTO_INCREMENT,
  `id_user_detail` int(255) NOT NULL,
  `password` varchar(75) NOT NULL,
  `level_akses` varchar(5) NOT NULL,
  `active_status` tinyint(4) NOT NULL,
  `last_online` datetime NOT NULL,
  `pass_change` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('7', '11', '$2a$12$.5dxcvPMe49YG4PEYwvKku47b/eF61a4x8Z5NgqvUJT/0o89tE5YS', 'mhs', '1', '2018-02-09 07:30:18', '1');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('12', '1', '$2a$12$NZbMmN98NqZvX5fA1Ll5L.uwg2PP3mqBoahsuhYIG6iVRxoOxb1ma', 'ptk', '1', '2018-02-09 07:45:27', '1');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('37', '25', '$2a$12$4FNJ1BZNy9H/MoxdnZQCK.1sPOygzUNCGtCS9HuXhRqqm9so9ANa6', 'ptk', '0', '2017-10-04 01:38:40', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('54', '42', '$2a$12$5jlBJI2DRz1ASTDuOC5cQeQEsy3zqB.dSB35urSWDQF.arJ3y0H5m', 'ptk', '1', '2017-10-27 02:29:51', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('72', '60', '$2a$12$tw9g.r1DfDtvXGdvzziVn.7cajCugg6FH2YrFxIdV4nYVxr987X6.', 'ptk', '1', '2017-06-16 13:20:59', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('111', '30', '$2a$12$DMxxaC/4C4sG48ta5lo6XOGPIgVnP21Zna7Up28yV.TaWwgfXNYY2', 'mhs', '1', '2017-11-05 06:40:36', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('123', '40', '$2a$12$9x2fm0DJrOWAcY6Cy4bTcOClZEcgLM5NHNPzDT3zslO9Jk626Jg9G', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('218', '135', '$2a$12$Vbe6b/Wl5pZ2ixj/m9LqDecnKqChJjZ08GPCVA1gLCrVHeZwAvIOa', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('219', '136', '$2a$12$1A6nqCcOlslonEO7dJa1ZOmONIOHUlZLWm/PLAlNNvhSbgLNglRci', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('270', '187', '$2a$12$xLteNc2w1fLu45VlYWSSa.RJY8Jtmz2DZfRpdL0QeV2grLfBixx5O', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('271', '188', '$2a$12$Cn9aV9iB21f8ul2dwqRriOTbjJ9mrrVnM0a9DHQnTNCeFRdID4JZq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('272', '189', '$2a$12$oP9GI.m6UGKATDP7lh1yquwIB9RrEDAgxWC9wyAbIUyaQa4.zv10m', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('273', '190', '$2a$12$8nXoR2Zc.vQlG0sLLvGV/.V.uD2AQxkJ2uhwJMWLfEQzmlhZQkTzK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('274', '191', '$2a$12$7nRATfy/wXjuBmq96uVux.NxoKb/wEipOCD.w.KAaAKVes0ykcU1y', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('275', '192', '$2a$12$s1qxPE7NrgfK7qdGLyrBfelYb9stw39laJ/IRfb9PW1bEGws0TuIK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('276', '193', '$2a$12$LlLC/aYc2n38FjBqF7Racu4b8.GofLYSTmDiBtyddxkyXZfhGFuW.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('277', '194', '$2a$12$B/YQu3wec6HFYXpWKCm3kurq50oP9Pth1zb9y9AOU2pkAQ/s.o/D2', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('278', '195', '$2a$12$TTJbucPPuRHozYaGtLA8VeOJDqm78pUsQSH0SkIw7coGN2V/lf/Gq', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('279', '196', '$2a$12$5HpJ.N3bmLd7vAOtICIPyOLWHXCyALJtdP.e1IUtasuOGv6iUyQp2', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('280', '197', '$2a$12$XDZ2ojzTNqZNo/6.6dPtY.C/.3yqN1se96BbutejRTwZn4vUm1gfC', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('281', '198', '$2a$12$XoHSGNZBbTTcmyxrczGEfun4O2duLewf3MjdvW9BAUk1kN64KXCy6', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('282', '199', '$2a$12$F1u6Y.DO1h2tYw..9OGffegEK4AqxkBBrr17xgn8PPFE7gjw48m82', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('283', '200', '$2a$12$AB6aWs4FWpRSswcZj4Ss9.r0w06Zmav7DDwd2wiB8cy3vSDl/qeO.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('284', '201', '$2a$12$vsHa/53sCW9PB6/moTX0jeODFqMpwHQX471Nx1wJNzfwuc2M6vw3S', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('285', '202', '$2a$12$NOCQqA7lrue4pLNqUhvxxuRI0BW3FzDqqws6WDQF2lxv9YFh4r5ee', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('286', '203', '$2a$12$wJ2QccWQA3iHM9PBsTsFP.M/Re3eEwORZgU1bL1ss3brVu9KV6B6i', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('287', '204', '$2a$12$eamDVf5drfEVQ4aNGUHdEOu9HgXNW2kTgBMu5sbdUsAAGMEuV9czm', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('288', '205', '$2a$12$ETFJPOU43XCysTZDfY73q.dqRtteXcP4C/cScKNjrtkD.14pOBEci', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('289', '206', '$2a$12$AFvbpl4sMR8YD5fF47uO/egw9vFKofF/EmmFRuURcEhV7kVpPyAku', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('290', '207', '$2a$12$1su3bnnUgxfkXXb7h3ohLerEIvqrJUPO3XQU9f17SedNXukZlhURq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('291', '208', '$2a$12$sMHcQrZxsznAkyzaO.F3PeRDNE6TtyAc5zG32ajHjKhrGzlzDwBKu', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('292', '209', '$2a$12$lKWvQSy0b8MrVk7k47h91.sEDufW3/5GPSpqednzsUn1n/cZk0crW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('293', '210', '$2a$12$pVmsKhKM.JBTRnDaGpp.L.KzAqAILBxHUN5pAP/A4I/XKTUteQQMO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('294', '211', '$2a$12$uKFcibqPnvM0lpQCulyXfeLtm2tGVo9DfjNGcxYVbFV5ePwWboGNq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('295', '212', '$2a$12$lYFKtiuqCcx2J12o7wABAe7w96EUC1CL1NJpNjzR4Tpmr2wIll6wS', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('296', '213', '$2a$12$TMuGJP53OKJbvQI/tezDxei1TT/dBKHKDueiC4CojXt.2FtyrTs0e', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('297', '214', '$2a$12$qzsw7u570/jayu1g7gVBD.9KUYbLBw2nrtqej0e.DCh83kM4TjtGW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('298', '215', '$2a$12$d91ibzUU9RUqEogUoeSfuuNQ/Zw/KOMUa4wUm7dbfu3MQx/uhbL8y', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('299', '216', '$2a$12$7c0CFaABqTzq5J4FRaoPRO4Ky6nEYC/f0BEeQApb4gvsLnq9XQgGK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('300', '217', '$2a$12$IN8dTDDl.iVE5ixzzL3ZSOB323sL43tg1AnWFs2/XyqExhfZ1qfmi', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('301', '218', '$2a$12$OgRts9Jju3L/JYVvrgi/Xe.H/1qaPYcjW6GWEpP8Kq.k5hPn.w92e', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('302', '219', '$2a$12$lPrsiiY.CxFY9jcOuUBil.sw.iJyVmj/BEn82QI7.8A62Xnq77IWy', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('303', '220', '$2a$12$sYt6GOjPQFjrre6z3W347Ou39Jp4Jfbl3xMVtMbro2Qh48koInDJe', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('304', '221', '$2a$12$bPGEcOzWBX.7oUFVhq3x/e1hdRHc5w1E4nMUDltgR2j./JJDoMfle', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('305', '222', '$2a$12$qXXVnHGF9aYYeCOYbbKUxOxTI5jM1cVZk5xR8.9/JpfAfHoMKGHzq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('306', '223', '$2a$12$IVVzHyT9p0QElGhxHGEPE.18m2gUL2QdiBdeH3fZpyZpQ27AYVYCW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('307', '224', '$2a$12$CxqYMyzjdIEfxh5jkT8VR.uDc3ZLr9193ee7UTW5T.gzwRkZvfLzu', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('308', '225', '$2a$12$gQjZRSrw.PWXngJNJwwzmubR3FRZ1p14vK73bEUsGKfVNFE5qa0CG', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('309', '226', '$2a$12$6ak3zliqRSYg3LqTIOeAseRGOk13el3rpRYumfBMc8AiQc6ILrfA6', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('310', '227', '$2a$12$.8/DGND.iw/wos2vnw8MNObBs/E.eLKzxlapuLEVuM13ihH4IYvxO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('311', '228', '$2a$12$XmUFpWYMgAs48jfncU38qec2lETIo1nxH0PAqi/TQBVs4/8IctdYe', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('312', '229', '$2a$12$5pHXHEBnVfSZFekehS01bOQetY4l130drJ/jsuhCiOxEWPCwkA6Qy', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('313', '230', '$2a$12$U2Lw2CYsd9oSKzUliRIwjuvrITBYhBLyB2TWGuAASGtJRkJ7WZ3ga', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('314', '231', '$2a$12$.8qUz/AkMEUsuZ3/GJqmFOAPf4Z2UvdpnFxS9VIVthbPWrygG8JFG', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('315', '232', '$2a$12$5YtwlyZ0ihOBAPRUekVC/uCo93js30VJr3fbY5N1qxfC6vAiiEYnO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('316', '233', '$2a$12$eMGm1FLo7pyJcCAre0Sbg.ttg6PbLfOTBuRETvl9C5/ZbBHOCYOTS', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('317', '234', '$2a$12$ygDKBbhZzb4z9BQYag4T7umNIdmc3pHSV7E545fGiJK/pUDFoXp1W', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('318', '235', '$2a$12$1O260oY1xjBR82pTleEvcuC6/30hBy0At7oZMa5Sl/GAHXQml29rW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('319', '236', '$2a$12$fONFde83I7/mIj00E71l8O1.xQU8SNz6E5YFOWOP7f3dIB/JsewYa', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('320', '237', '$2a$12$Yzio3ZFzcJSRTba.mKx9/OUex5JdtEzPILA/zGRZf7tb1qPKX21wy', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('321', '238', '$2a$12$TQrZxnA0DVqtqrAFhlEJiudh/LVjVY1p62VvW.vfgtY3gJv.IVrDa', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('322', '239', '$2a$12$bJKUlWkwkA3DqSsTGrQMx.Ff/bB/M2La5oSVgiRoWmJz2Z0ppx8t.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('323', '240', '$2a$12$g6sM5Z1AjRrh.e2RvvSLteCq090FfsubuACsUb6nNovsUaavwfgOO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('324', '241', '$2a$12$53QLAi2B5W5H2tTwQe33DOo0HMpVtEssFTK7JJE20HkFCD9Snw2I2', 'mhs', '0', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('325', '242', '$2a$12$uOWey8fuWCG6Ou3Z3CWzVOtleK6L959aYk2H61ZF5qj/fS/67Ce2a', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('326', '243', '$2a$12$7NC7KC/MXSjy9w5AnAH3NO18KQv6yJOJddMmNU1gH4uXnAuEQaMVe', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('327', '244', '$2a$12$WGi00w2yF07dfQPcYA0Ew.TEnrKoSL4QjSiQK1XQxgEfECnRpUXse', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('328', '245', '$2a$12$g/OKhKp9Gn5ibEee3O.EleYIm7H9rz44LaN6i810L7VkpgJP8qfJi', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('329', '246', '$2a$12$mtryWTw6L80nTLIGj3PivOiXSpfdeiqwfUC1RBzL4oAgyenWZUZqm', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('330', '247', '$2a$12$e.xfoBEwzSsTgCh18weMzOppeaZI/IK33yPXNV42tceFAwpRMGVfG', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('331', '248', '$2a$12$g/7GOrAdA7ccrUnhUfB0XuOHRng/c/PkdVnhYVwVuZQsgmHDUFVtK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('332', '249', '$2a$12$idCQOazjpzZKCfJBzScnWeauGNMYyk1KiveHjqxtTc31Gs0zwl.5m', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('333', '250', '$2a$12$OFqndAYeIH2xcBMKH4xnMOIgCEArDmLBhTVzNvu8aNxC5HuN2u.6S', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('334', '251', '$2a$12$wnAn81STkr0vNDQQJNCf9OLPl5UiEfoOncoB9j1g3zVelPrZ2wjUu', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('335', '252', '$2a$12$VHDCy1.YaJqnV6McT7WBZOqByNxiWymfErTFrIf81BW49emA4wzj.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('336', '253', '$2a$12$7fEfvLiWVPV4XUfb.v9TD.SB5HGQsOK4/Fca.jRdZBSCzCErFb3ua', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('337', '254', '$2a$12$x3gR/HGqM3eXppU20aGkgOPzCT.S0EXT64jS8dhAFX0VswifZiKFO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('338', '255', '$2a$12$dA.InV2dsV7XXeQQWYCphOAcIiI6ILz58M21Wrp39y09i/ADeXX.a', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('339', '256', '$2a$12$v8FEwHDuCEoQb.GJdPBeF.513CUxJasOFb.K1KFuRITP0NNFG2A5W', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('340', '257', '$2a$12$Tl3NcA4Z8CA0CHaSMtTY2uXK2BUjJVOa3XmcHf9Vx2cMGsWn2VTWO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('341', '258', '$2a$12$uaunx4XDA7.2vcAht9RWWO1MYIVawQ8NCBubgYl4UHz8ddmuv3kau', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('342', '259', '$2a$12$0ftWCCJa/MDWXWOUQO3ngeMZYiZrPa0RutjVhc0xhsTbfQ/r0LO0.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('343', '260', '$2a$12$x73DfKk68PpbP7NfJNHkh.0IaYGV3RPZ8MIbVXCWGV6Qn4HSkxTme', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('344', '261', '$2a$12$gLqvLejOAHZvSIJ6aw6WMub3VK4i1u1ZurBOUHG/BAkP2kCBLwsE2', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('345', '262', '$2a$12$F92i1DCnJc/nEyTVB8/iVe0MqwnDMVYvIgUszgTmBxzMZ9.RjpZja', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('346', '263', '$2a$12$DULIDM4kWxFkYEhy/GtZluH7kebqDHd0r5TusKnicgquBcmcYOKqa', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('347', '264', '$2a$12$VgQlOOQ6ghYTQxAZZNVwKORCwvZT/KM7vBNdvCZLTQC.O47YIxcRK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('348', '265', '$2a$12$xY1UrZ/vrvo0I1ifL2VQvOE9u570HQr4LSm4GFv.9AYH0nv/kNR5.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('349', '266', '$2a$12$O9TMEY5vEMI4PT6WbxPWqOjdTDzX.A5t2lFGJgueCTQJnDykm1kVK', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('350', '267', '$2a$12$Jxc04CPSuSJk34RLAqgxjOyt8Opr6ieU9tbZaoN6z5ERRNdJcJGMq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('351', '268', '$2a$12$bo0K85wDShmSfMNxyqGx.eZFxzBLep1qzyiun1uuHRjuoFFfzuVv.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('352', '269', '$2a$12$vFkXHc9p8QRN9/wUTAKJiOmpv3WI7vFm3QmHcjE3kHirfy8YcYPHq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('353', '270', '$2a$12$GeHAYEl7Xce4e.S9V9nY0.vkBrgg7hhpwNOj9tvfEp.lgh9JJpQQW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('354', '271', '$2a$12$3XbRmsCiHJfUNSIxSqoeye.S.cSjXmdEm.0lJj9r6.YLLoUEQ3wdS', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('355', '272', '$2a$12$sNWQUVEfcnDB9Xv9aPkH7eb7RSFt9AOJWwLzdEzzfYCaFBqHwJLIO', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('356', '273', '$2a$12$lf0Ur4UQ8k86G7uPpPvKi.LnGHhjVNoNj7gci735qoPanMvsUX9D6', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('357', '274', '$2a$12$10mfS4XWHNsxHs8BdHHole2wO2SmmA425A1t79mILV./epdNqsQRq', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('358', '275', '$2a$12$nMFa.i3BJOLkEHPIKmdUUOoAXEi33jorG8/kEcxfFWg0E3zB65XyS', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('359', '276', '$2a$12$XK9gLWujA47ssuVpTC5AqOiIHc21hGBG5hEIO281.NSFnvP/BVVku', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('360', '277', '$2a$12$ZbCOfUzYIxhd4.izhuiyZ.Xi4UGHaiBf72P9Zwas6t7scuFrSOLhW', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('361', '278', '$2a$12$5ONI7NgWqhGBkw6SbteoG.5nTyE3F2i.Mn991J2rwOkCblJ5VCUG6', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('362', '279', '$2a$12$HGB3ncPSCHxHMdgaFcr/i.G/eoDJYilnjrx4M8jl22TRrZYM9pqB.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('363', '280', '$2a$12$220llwPKyWWhU/0hc1nsH.vlSdIpErV.q/o1hygp/2OR84ff2AjDu', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('364', '281', '$2a$12$oz.trY29IKc4cmYdFpB/ee4GgTfFENsTe5D8uWfcGq0pUqQoUZLvC', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('365', '282', '$2a$12$pHsDbd71q2nWaT8jJqpCsewgPTjjpdnjOOBungir1hckbvWcggIl.', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('366', '283', '$2a$12$7Cemb/3DA.suu7BhTZABMeFMVf/EPSMAlz3G8xynDUy3cps7koKxS', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('367', '284', '$2a$12$mclARSaovjg2Did63goLROtIK3gtdqy0D6MpkPR5vdlCPtIMCT0qm', 'mhs', '1', '0000-00-00 00:00:00', '0');
INSERT INTO `tbl_user` (`id_user`, `id_user_detail`, `password`, `level_akses`, `active_status`, `last_online`, `pass_change`) VALUES ('368', '285', '$2a$12$jEhwW67Mr3sGiFJkEzxgMOE9yLNwuf3L5OHP.5fl5GVOzr2x2/PLm', 'mhs', '1', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tbl_user_admin
#

DROP TABLE IF EXISTS `tbl_user_admin`;

CREATE TABLE `tbl_user_admin` (
  `id_user_admin` int(255) NOT NULL AUTO_INCREMENT,
  `id_user_detail` int(255) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(75) NOT NULL,
  `uncrypt_password` varchar(10) NOT NULL,
  `level_akses` varchar(5) NOT NULL,
  `active_status` tinyint(4) NOT NULL,
  `last_online` datetime NOT NULL,
  PRIMARY KEY (`id_user_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user_admin` (`id_user_admin`, `id_user_detail`, `username`, `password`, `uncrypt_password`, `level_akses`, `active_status`, `last_online`) VALUES ('1', '0', 'admin', '$2a$12$V9hafb9rD3u6an0GdH0ZkunHoqiurlkvnGr6Z3DtAhB/34qceA3Wy', 'admin', 'admin', '1', '2018-02-09 10:15:18');


#
# TABLE STRUCTURE FOR: tbl_visitor_logs
#

DROP TABLE IF EXISTS `tbl_visitor_logs`;

CREATE TABLE `tbl_visitor_logs` (
  `visitor_ID` bigint(100) unsigned NOT NULL AUTO_INCREMENT,
  `visitor_IP` varchar(15) NOT NULL DEFAULT '',
  `visitor_id_user` int(255) NOT NULL,
  `visitor_user_level` varchar(10) NOT NULL,
  `visitor_referer` varchar(255) NOT NULL DEFAULT '',
  `visitor_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `visitor_agent` varchar(255) DEFAULT NULL,
  `visitor_session` varchar(255) NOT NULL,
  `visitor_city` varchar(90) NOT NULL,
  `visitor_region` varchar(90) NOT NULL,
  `visitor_country` varchar(90) NOT NULL,
  `visitor_os` varchar(255) NOT NULL,
  `visitor_browser` varchar(255) NOT NULL,
  `visitor_isp` varchar(255) NOT NULL,
  PRIMARY KEY (`visitor_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_visitor_logs` (`visitor_ID`, `visitor_IP`, `visitor_id_user`, `visitor_user_level`, `visitor_referer`, `visitor_date`, `visitor_agent`, `visitor_session`, `visitor_city`, `visitor_region`, `visitor_country`, `visitor_os`, `visitor_browser`, `visitor_isp`) VALUES ('1', '127.0.0.1.', '1', 'ptk', 'http://localhost/siakad-uncp/login', '2017-10-04 07:28:46', 'Desktop', '', '', '', '', 'Windows 10', 'Chrome', '');
INSERT INTO `tbl_visitor_logs` (`visitor_ID`, `visitor_IP`, `visitor_id_user`, `visitor_user_level`, `visitor_referer`, `visitor_date`, `visitor_agent`, `visitor_session`, `visitor_city`, `visitor_region`, `visitor_country`, `visitor_os`, `visitor_browser`, `visitor_isp`) VALUES ('2', '127.0.0.1.', '11', 'mhs', 'http://localhost/siakad-uncp/login', '2017-10-04 07:30:47', 'Mobile', '', '', '', '', 'Android', 'Chrome', '');
INSERT INTO `tbl_visitor_logs` (`visitor_ID`, `visitor_IP`, `visitor_id_user`, `visitor_user_level`, `visitor_referer`, `visitor_date`, `visitor_agent`, `visitor_session`, `visitor_city`, `visitor_region`, `visitor_country`, `visitor_os`, `visitor_browser`, `visitor_isp`) VALUES ('3', '127.0.0.1.', '1', 'admin', 'http://localhost/siakad-uncp/login', '2017-10-30 06:38:31', 'Desktop', '', '', '', '', 'Windows 10', 'Microsoft Edge', '');


